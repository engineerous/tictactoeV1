

import React, { useState, useEffect } from "react";





const GameBoard = () => {
    const [winner, setWinner] = useState("");
    const [colors, setColor] = useState(
       ()=>{ 
        let temp = Array(9).fill("#080f0f")
        return temp; 
       });




    const [boardgame, setboard] = useState(()=>{
     return  Array(9).fill("");
    });

    const [gameMessage, setGameMessage] = useState("null");
 
    const [turn, setturn] = useState(()=>{
    let flip = Math.floor(Math.random() * 2)

    if (flip === null)
    setGameMessage(''); 
    if (flip === 0)
    {setGameMessage("Your Turn")
     }
    if (flip === 1)
    setGameMessage("Opponets Turn")
    return flip;     
});
    
useEffect(() => {
    console.log("use effect")
    //let result = checkForWinner(); 
    
   let results = checkForWinner(); 
   console.log("results : " + results)
   if (results === false)
   runOpponent(); 
   else
  { setGameMessage(results + " is the winner!")
   
  
  }
   
                          function colorBox(i1, i2, i3)
                            {

                                let temp = Array(9).fill("#080f0f") 
                                temp[i1] = "#EEE8AA"
                                temp[i2] = "#EEE8AA"
                                temp[i3] = "#EEE8AA"
                                setColor(()=> {
                                   return temp; 
                            });
                        }
     
                          

                           function checkForWinner() {

                           for (let i = 0; i < 9; i = i + 3)
                           {
                               let temp = boardgame[i] + boardgame[i+ 1] + boardgame[i +2]
                                if (temp === "XXX")
                                {
                                    setWinner("Computer")
                                   colorBox(i, i+1, i+ 2)
                                    return "Computer"; 
                                }
                                if (temp === "OOO")
                                {
                                    setWinner("You")
                                    colorBox(i, i+1, i+ 2)
                                    return "You"; 
                                }  

                           } 

                           for (let i = 0; i < 3; i++)
                           {
                               let temp2 = boardgame[i] + boardgame[i+ 3] + boardgame[i+ 6]
                               if (temp2 === "XXX")
                               {
                                   setWinner("Computer")
                                   colorBox(i, i+3, i + 6); 
                                   return "Computer"; 
                               }
                               if (temp2 === "OOO")
                               {
                                   setWinner("You")
                                   colorBox(i, i+3, i + 6); 
                                   return "You"; 
                               } 
                           }

                            let temp3 = boardgame[0] + boardgame[4] + boardgame[8]; 
                            if (temp3 === "XXX")
                            {
                                setWinner("Computer")
                                colorBox(0, 4, 8)
                                return "Computer"; 
                            }
                            if (temp3 === "OOO")
                            {
                                setWinner("You")
                                colorBox(0, 4, 8)
                                return "You"; 
                            } 

                            let temp4 = boardgame[2] + boardgame[4] + boardgame[6]; 
                            if (temp4 === "XXX")
                            {
                                setWinner("Computer")
                                colorBox(2, 4, 6)
                                return "Computer"; 
                            }
                            if (temp4 === "OOO")
                            {
                                setWinner("You")
                                colorBox(2, 4, 6)
                                return "You"; 
                            } 




                           return false; 
                           }






                            function runOpponent() {
                                 let flag = false; 
                                 setTimeout(  function() {

                                     if (turn === 1)
                                    { console.log("running Opponent!")
        
                                    for (let i in boardgame)
                                    { 
                                        
                                        if (flag === false)
                                        {
                                        if (boardgame[i] === "")
                                        { 
                                            flag = true;
                                            
                                            setboard(()=> {
                                                let temp = Array(9).fill("")
                                                    for (let i in boardgame)
                                                    {
                                                        
                                                        temp[i] = boardgame[i];


                                                    }
                                                    
                                                
                                                    temp[i] = "X";
                                                    console.log("Game turn to change!!")
                                                    
                                                    setGameMessage("Your Turn")
                                                    setturn(()=>{
                                                        return 0; 
                                                    });
                                                    console.log(temp) 
                                                    return temp;
                                                
                                                })  } }  }

 }  }, Math.ceil(Math.random() * 2000));
                                            }
                                            
                                            
                }, [boardgame, turn]);


  
    
  function setMoveHandler(e) {
       //first check if user is auth to move
      
       if (turn ===0 && winner=== "")
       {
        // check if board position is occupied
        if (boardgame[e.target.id] === "")
        { console.log(boardgame)
            setboard(()=> {
                let temp = Array(9).fill("")
                for (let i in boardgame)
                {
                    temp[i] = boardgame[i];


                }
                temp[e.target.id] = "O";
                setturn(()=>{
                    return 1; 
                });
                setGameMessage("Opponents Turn")
                return temp; 
            })
        }


       }
       
    
       }

       

      

      
    return (
        <div>
            <div id="title" className="title">TicTacToe</div>
        <div id= "container" className="grid-container">
   
        <div id= "0" className='item' style={{backgroundColor: colors[0]}} onClick={(e)=> { setMoveHandler(e)}}>{boardgame[0]}</div>
        <div id= "1" className='item'  style={{backgroundColor: colors[1]}}  onClick={(e)=> { setMoveHandler(e)}}>{boardgame[1]}</div>
        <div id= "2" className='item'  style={{backgroundColor: colors[2]}} onClick={(e)=> { setMoveHandler(e)}}>{boardgame[2]}</div>
        <div id= "3" className='item'  style={{backgroundColor: colors[3]}}  onClick={(e)=> { setMoveHandler(e)}}>{boardgame[3]}</div>
        <div id= "4" className='item'  style={{backgroundColor: colors[4]}}  onClick={(e)=> { setMoveHandler(e)}}>{boardgame[4]}</div>
        <div id= "5" className='item'  style={{backgroundColor: colors[5]}}  onClick={(e)=> { setMoveHandler(e)}}>{boardgame[5]}</div>
        <div id= "6" className='item'  style={{backgroundColor: colors[6]}}  onClick={(e)=> { setMoveHandler(e)}}>{boardgame[6]}</div>
        <div id= "7" className='item'  style={{backgroundColor: colors[7]}} onClick={(e)=> { setMoveHandler(e)}}>{boardgame[7]}</div>
        <div id= "8" className='item'  style={{backgroundColor: colors[8]}}  onClick={(e)=> { setMoveHandler(e)}}>{boardgame[8]}</div>
      
        </div>
        <div>{boardgame}</div>
        <div className="message" text-align="left">Message:{gameMessage}</div>
         </div>

    )
} 

export default GameBoard
;

/*

  


*/