import React, { useState, useEffect } from "react";
import GameBoard from './components/gameboard.js'
import  './App.css';

function App() {

  


  return (
    
    <div className="App">
   
   <GameBoard  />
    </div>
  );
}

export default App;
